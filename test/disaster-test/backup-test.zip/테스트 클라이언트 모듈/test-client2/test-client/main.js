let reqNumber;
let delay;
let path;
let count;
let index;

for(let i=0; i<process.argv.length; i++){
    const argv = process.argv[i];
    switch(argv){
        case '--req':
            reqNumber = process.argv[i+1];
            break;
        case '--delay':
            delay = process.argv[i+1];
            break;
        case '--testpath':
            path = process.argv[i+1];
            break;
        case '--totalcount':
            count = process.argv[i+1];
            break;
        case '--clientindex':
            index = process.argv[i+1];
            break;
    }
}

const User = require('./lib/user.js');
const user = new User(reqNumber, delay, path, count, index);
user.testStarting();
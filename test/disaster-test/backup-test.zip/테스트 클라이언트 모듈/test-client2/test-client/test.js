const obj= new Object;

console.log(obj.body.includes == undefined);
